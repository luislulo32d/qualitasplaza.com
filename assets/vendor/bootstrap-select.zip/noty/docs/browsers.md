!> This data is provided by BrowserStack Automate 


#### Local run  2017 07 27T17:31:03.314Z 

| OS | Browser | Result | Details | 
| --- | --- | --- | --- | 
| Windows 10 | opera 46.0  | done | [view](https://www.browserstack.com/automate/builds/7d2483377687d162b9bc20fcaf3cb1bfb8f5bec0/sessions/c259644238854e4628696d8cfea9482b96a78a07?auth_token=f87c9cb1ab62bb7b85af973cc2a1b03bd9d35fbc6a9e38b716fe38b01c4c3480) |
| Windows 10 | chrome 59.0  | done | [view](https://www.browserstack.com/automate/builds/7d2483377687d162b9bc20fcaf3cb1bfb8f5bec0/sessions/dc87007925cb5729ac8aa2a6136aab1fb6808cc1?auth_token=04d2d0b39bcdbb76153ee28e3acf67099ecbd9a093c6176df9ad892c083663c6) |
| OS X El Capitan | safari 9.1  | done | [view](https://www.browserstack.com/automate/builds/7d2483377687d162b9bc20fcaf3cb1bfb8f5bec0/sessions/0c60211cab5840456ac824443e3be99b195597b5?auth_token=9daf8b81531fe858108d9d76317b171c7dca69dee3ac3a25e065810fd353b837) |
| Windows 10 | firefox 54.0  | done | [view](https://www.browserstack.com/automate/builds/7d2483377687d162b9bc20fcaf3cb1bfb8f5bec0/sessions/336cf3a8db5363d7683f01392d4d328fce18838a?auth_token=e93ad65f77003c53f0e7392f2bbd38d56811d1d6ce4e1f9f098494caa240ef21) |
| Windows 10 | edge 15.0  | done | [view](https://www.browserstack.com/automate/builds/7d2483377687d162b9bc20fcaf3cb1bfb8f5bec0/sessions/a2bb1f252f478c5b5cd4fdc06158830305120ea2?auth_token=c75ad2904602c489145eaf2ce18b8f5723a843cb6c8dcc62a60982dc6109ef27) |
| Windows 8 | ie 10.0  | done | [view](https://www.browserstack.com/automate/builds/7d2483377687d162b9bc20fcaf3cb1bfb8f5bec0/sessions/d85b895f81c51f9cd5c72c225c9f155b331902c6?auth_token=bd85550ce628686d6485062a32cc869abf2dcb7a2b9862b3884ebc7d4283d344) |
